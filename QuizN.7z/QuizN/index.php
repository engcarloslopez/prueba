<!-- CARLOS ALBERTO LOPEZ VEGA -->
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Formulario PHP</title>
    </head>
    <body>
    <center>

    <?php
    	$numero1 = $numero2 = $eNumero1 = $eNumero2 = "";
        $estado1 = $estado2 = false;
        $resultado;
	?>


<!-------VISUALIZACION-------->

<h2>OPERACIONES MATEMATICAS</h2>
        <p><span class="error">* Campos Requeridos</span></p>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>">
            Tabla a generar: <input type="text" name="numero1" value="<?php echo $numero1;?>">
            <span class="error">* <?php echo $eNumero1;?></span> 
            <select name="operador">
                <option value="+">+</option>
                <option value="-">-</option>
                <option value="*">*</option>
                <option value="/">/</option>
            </select>
            Limite de la tabla: <input type="text" name="numero2" value="<?php echo $numero2;?>">
            <span class="error">* <?php echo $eNumero1;?></span> <br>
            
            
            <br><br>  
            <input type="submit" name="submit" value="Calcular">
             <br><br> 
        </form>



        <!-- VALIDACION -->

<?php
    
        
       if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    	//-------NUMERO 1-----
   			if (empty($_POST['numero1'])) {
        		$eNumero1 = 'Debe digitar un valor';
    		} else {
        		$numero1 = test_input($_POST['numero1']);
               		if (!preg_match("/^[0-9]+$/",$numero1)) {
            			$eNumero1 = "Solo números!"; 
        			}else {
            			$estado1 = true;
        			}
    			}
 		//-------NUMERO 2-----
   			if (empty($_POST['numero2'])) {
        		$eNumero2 = 'Debe digitar un valor numerico';
    		} else {
        		$numero2 = test_input($_POST['numero2']);
                	if (!preg_match("/^[0-9]+$/",$numero2)) {
            			$eNumero2 = "Solo se permiten números"; 
        			}else {
            			$estado2 = true;
        			}
   			 }
   		//-------OPERACIONS--------
    if(!empty($_POST['operador']=='+')){

    	if($estado1 && $estado2){
    	for($i=0; $i<=$numero2; $i++) 
		{
			
			 echo "$numero1 + $i = ". ($numero1+$i) . "<br/>";
		}
		}
		else{
			echo "Solo se permiten numeros";
		}

    } else if(!empty($_POST['operador']=='-')){
       
     if($estado1 && $estado2){
    	for($i=0; $i<=$numero2; $i++) 
		{
			
			 echo "$numero1 - $i = ". ($numero1-$i) . "<br/>";
		}
		}
		else{
			echo "Solo se permiten numeros";
		}


    } else if(!empty($_POST['operador']=='*')){
      
      if($estado1 && $estado2){
    	for($i=0; $i<=$numero2; $i++) 
		{
			
			 echo "$numero1 * $i = ". ($numero1*$i) . "<br/>";
		}
		}
		else{
			echo "Solo se permiten numeros";
		}


    } else if(!empty($_POST['operador']=='/')){
       
       if($estado1 && $estado2){
    	for($i=0; $i<=$numero2; $i++) 
		{
			
			 echo "$numero1 / $i = ". ($numero1/$i) . "<br/>";
		}
		}
		else{
			echo "Solo se permiten numeros";
		}


    }
    
}


function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
        
    
    ?>
</center>
    </body>
</html>
